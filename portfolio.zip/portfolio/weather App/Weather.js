//http://api.weatherapi.com/v1/current.json?key= 817e5c0566894585a2354558241311&q=Faisalabad&aqi=no


let temperaturefield = document.querySelector(".temp")
const locationField = document.querySelector(".time_location p")
const dateandtimeFiled = document.querySelector(".time_location span");
const conditionFiled = document.querySelector(".condition p");
const searchFiled = document.querySelector(".search_field ");
const form = document.querySelector('form');


form.addEventListener('submit' , searchForLocation)


let target = 'lahore'
const fetchResults = async (targetLocation)=>{
    let url = `http://api.weatherapi.com/v1/current.json?key= 817e5c0566894585a2354558241311&q=${targetLocation}&aqi=no`

    const res  = await fetch(url)
    
    const data = await res.json()
    console.log(data)

    let locationName = data.location.name
    let time = data.location.localtime

    let temp = data.current.temp_c

    let condition = data.current.condition.text

    updateDetails(temp , locationName,time,condition)
}


function updateDetails(temp,locationName,time,condition){

   let splitDate = time.split(' ')[0]
   let splittime = time.split(' ')[1]

   let currrentDay = GetdayName(new Date(splitDate).getDay())

    temperaturefield.innerText = temp
    locationField.innerText = locationName
    dateandtimeFiled.innerText = `${splitDate} ${currrentDay} ${splittime} `
    conditionFiled.innerText = condition

}

function searchForLocation(e){
    e.preventDefault()

    target = searchFiled.value
    fetchResults(target)
}


fetchResults(target);


function GetdayName(number){
    switch(number){
        case 0:
            return 'Sunday'
        case 1:
            return 'Monday'
        case 2:
            return 'Tuesday'
        case 3:
             return 'Wednesday'
        case 4:
             return 'Thursday'
        case 5:
            return 'Friday'
        case 6:
            return 'Saturday'
                                                                                            

    }
}